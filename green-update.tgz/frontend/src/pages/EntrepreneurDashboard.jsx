import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import dayjs from "dayjs";
import { API_ORIGIN, apiRequest } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { buildToolProgressList } from "../utils/toolProgress";
import { TOOLS_CATALOG } from "../data/toolsCatalog";

const DEFAULT_FORMS = {
  valueProposition: "",
  customerSegments: "",
  channels: "",
  revenueStreams: "",
  environmentalImpact: "",
  socialImpact: "",
  financialPlan: ""
};

export default function EntrepreneurDashboard() {
  const { token, firebaseUser } = useAuth();
  const [courses, setCourses] = useState([]);
  const [learning, setLearning] = useState([]);
  const [projects, setProjects] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [groups, setGroups] = useState([]);
  const [message, setMessage] = useState("");
  const [joinCode, setJoinCode] = useState("");

  const [newProject, setNewProject] = useState({
    title: "",
    type: "BMC"
  });

  async function loadAll() {
    const [coursesRes, learningRes, projectsRes, sessionsRes, groupsRes] = await Promise.all([
      apiRequest("/courses", { token }),
      apiRequest("/courses/my/learning", { token }),
      apiRequest("/projects/my", { token }),
      apiRequest("/sessions/my", { token }),
      apiRequest("/groups/my", { token })
    ]);

    setCourses(coursesRes.courses || []);
    setLearning(learningRes.learning || []);
    setProjects(projectsRes.projects || []);
    setSessions(sessionsRes.sessions || []);
    setGroups(groupsRes.groups || []);
  }

  useEffect(() => {
    if (!token) return;
    loadAll().catch((err) => setMessage(err.message));
  }, [token]);

  const toolProgress = useMemo(() => {
    return buildToolProgressList({ uid: firebaseUser?.uid, projects });
  }, [firebaseUser?.uid, projects]);

  const usedTools = useMemo(() => {
    return toolProgress.filter((tool) => tool.answerPercent > 0 || tool.percent > 0);
  }, [toolProgress]);

  async function enroll(courseId) {
    await apiRequest(`/courses/${courseId}/enroll`, { method: "POST", token });
    setMessage("Course enrolled.");
    await loadAll();
  }

  async function saveProgress(courseId, moduleIndexesText) {
    const modulesCompleted = moduleIndexesText
      .split(",")
      .map((v) => Number(v.trim()))
      .filter((n) => Number.isFinite(n));

    await apiRequest(`/courses/${courseId}/progress`, {
      method: "POST",
      token,
      body: { modulesCompleted }
    });
    setMessage("Progress updated.");
    await loadAll();
  }

  async function createProject(e) {
    e.preventDefault();
    await apiRequest("/projects", {
      method: "POST",
      token,
      body: {
        title: newProject.title,
        type: newProject.type,
        stage: "idea",
        forms: DEFAULT_FORMS
      }
    });
    setNewProject({ title: "", type: "BMC" });
    setMessage("Project created.");
    await loadAll();
  }

  async function joinGroup(e) {
    e.preventDefault();
    if (!joinCode.trim()) {
      setMessage("Please enter a group code.");
      return;
    }
    await apiRequest("/groups/join", {
      method: "POST",
      token,
      body: { code: joinCode.trim() }
    });
    setJoinCode("");
    setMessage("Joined group.");
    await loadAll();
  }

  async function updateProjectForms(projectId, forms, submit = false) {
    await apiRequest(`/projects/${projectId}/forms`, {
      method: "PUT",
      token,
      body: { forms, submit }
    });
    setMessage(submit ? "Project submitted for review." : "Project draft updated.");
    await loadAll();
  }

  async function uploadDocument(projectId, file) {
    const formData = new FormData();
    formData.append("file", file);
    await apiRequest(`/projects/${projectId}/upload`, {
      method: "POST",
      token,
      body: formData,
      formData: true
    });
    setMessage("Document uploaded.");
    await loadAll();
  }

  return (
    <div className="dashboard-grid">
      {message ? <p className="info">{message}</p> : null}

      <section className="card span-2">
        <h2>Entrepreneur dashboard</h2>
        <p>Build your project, follow tool progress, and track mentoring and learning activity.</p>
      </section>

      <section className="card span-2">
        <h2>My tool progress</h2>
        <p>Used tools: {usedTools.length} / {toolProgress.length}</p>
        <div className="tool-progress-list">
          {toolProgress.map((tool) => (
            <article key={tool.toolKey} className="tile tool-progress-item">
              <div>
                <h3>{tool.title}</h3>
                <p>{getVisibleProgressLabel(tool)}</p>
                <p className="subtitle">{tool.answeredCount}/{tool.totalCount} answers filled</p>
                {tool.hasMentorCorrection ? (
                  <span className={`correction-badge correction-badge-${getCorrectionStatus(tool.mentorReview)}`}>
                    {getCorrectionLabel(tool.mentorReview)}
                  </span>
                ) : null}
                {getCorrectionStatus(tool.mentorReview) === "no" && (tool.mentorReview?.comment || tool.mentorReview?.recommendation) ? (
                  <p className="mentor-correction-comment">{tool.mentorReview.comment || tool.mentorReview.recommendation}</p>
                ) : null}
              </div>
              <Link className="btn" to={`/app/tools/${tool.toolKey}`}>Continue</Link>
            </article>
          ))}
        </div>
      </section>

      <section className="card span-2">
        <h2>Learning paths</h2>
        <p>Classic entrepreneurship and green entrepreneurship tracks.</p>
        <div className="grid-2">
          {courses.map((course) => (
            <article key={course.id} className="tile">
              <h3>{course.title}</h3>
              <p>{course.description}</p>
              <p><strong>Track:</strong> {course.track} | <strong>Level:</strong> {course.level}</p>
              <p><strong>Path:</strong> {course.learningPath}</p>
              {(course.modules || []).map((module, idx) => (
                <div key={`${course.id}-m-${idx}`} className="module">
                  <p>{idx + 1}. {module.title}</p>
                  {module.videoUrl ? <a href={module.videoUrl} target="_blank" rel="noreferrer">Video</a> : null}
                  {module.documentUrl ? <a href={module.documentUrl} target="_blank" rel="noreferrer">Download doc</a> : null}
                </div>
              ))}
              <button className="btn" onClick={() => enroll(course.id)}>Enroll</button>
            </article>
          ))}
        </div>
      </section>

      <section className="card span-2">
        <h2>Mentor groups</h2>
        <form onSubmit={joinGroup} className="inline">
          <input placeholder="Enter group code" value={joinCode} onChange={(e) => setJoinCode(e.target.value)} />
          <button className="btn primary">Join</button>
        </form>
        {groups.length === 0 ? <p>No groups joined yet.</p> : null}
        <div className="grid-2">
          {groups.map((item) => (
            <article key={item.group?.id || item.id} className="tile">
              <h3>{item.group?.title || item.title}</h3>
              <p>{item.group?.description || item.description}</p>
              {(item.group?.lessons || item.lessons || []).map((lesson, idx) => (
                <div key={`${item.group?.id || item.id}-lesson-${idx}`} className="module">
                  <p>{idx + 1}. {lesson.title}</p>
                  {lesson.content ? <p>{lesson.content}</p> : null}
                  {lesson.videoUrl ? (
                    <>
                      <video className="mentor-private-video" controls src={resolveMediaUrl(lesson.videoUrl)}></video>
                      <a href={resolveMediaUrl(lesson.videoUrl)} target="_blank" rel="noreferrer">Open video</a>
                    </>
                  ) : null}
                  {lesson.documentUrl ? <a href={resolveMediaUrl(lesson.documentUrl)} target="_blank" rel="noreferrer">Download doc</a> : null}
                </div>
              ))}
            </article>
          ))}
        </div>
      </section>

      <section className="card span-2">
        <h2>My learning progress</h2>
        {learning.length === 0 ? <p>No enrolled courses yet.</p> : null}
        {learning.map((item) => (
          <LearningProgressCard key={item.enrollment.id} item={item} onSave={saveProgress} />
        ))}
      </section>

      <section className="card">
        <h2>Create project</h2>
        <form onSubmit={createProject} className="form-stack">
          <input placeholder="Project title" value={newProject.title} onChange={(e) => setNewProject({ ...newProject, title: e.target.value })} required />
          <select value={newProject.type} onChange={(e) => setNewProject({ ...newProject, type: e.target.value })}>
            <option value="BMC">Business Model Canvas</option>
            <option value="GREEN_BMC">Green BMC</option>
            <option value="GREEN_BUSINESS_PLAN">Green Business Plan</option>
          </select>
          <button className="btn primary">Create</button>
        </form>
      </section>

      <section className="card span-2">
        <h2>Project workspace</h2>
        {projects.length === 0 ? <p>No projects yet.</p> : null}
        {projects.map((project) => (
          <ProjectEditor key={project.id} project={project} onSave={updateProjectForms} onUpload={uploadDocument} />
        ))}
      </section>

      <section className="card">
        <h2>Mentoring sessions</h2>
        {sessions.length === 0 ? <p>No sessions scheduled.</p> : null}
        {sessions.map((session) => (
          <div key={session.id} className="tile">
            <p><strong>{session.topic}</strong></p>
            <p>{dayjs(session.startAt).format("YYYY-MM-DD HH:mm")} to {dayjs(session.endAt).format("HH:mm")}</p>
            <a href={session.meetingLink} target="_blank" rel="noreferrer">Open meeting</a>
            <p>Status: <strong>{session.status}</strong></p>
          </div>
        ))}
      </section>
    </div>
  );
}

function getProjectTool(project) {
  return TOOLS_CATALOG.find((tool) => {
    if (tool.key === "green-business-model") return ["GREEN_BMC", "BMC"].includes(project.type);
    if (tool.key === "green-business-plan") return project.type === "GREEN_BUSINESS_PLAN";
    return false;
  }) || null;
}

function isVideoLesson(lesson) {
  const target = `${lesson?.mimeType || ""} ${lesson?.path || ""}`.toLowerCase();
  return target.includes("video") || [".mp4", ".webm", ".mov", ".m4v"].some((ext) => target.includes(ext));
}

function resolveMediaUrl(url) {
  if (!url) return "";
  if (/^https?:\/\//i.test(url)) return url;
  if (url.startsWith("/")) return `${API_ORIGIN}${url}`;
  return url;
}

function getCorrectionStatus(review) {
  if (!review?.reviewedAt) return null;
  return review.correctionStatus || (review.corrected || review.verified ? "yes" : "no");
}

function getCorrectionLabel(review) {
  const status = getCorrectionStatus(review);
  if (status === "yes") return "Yes";
  if (status === "no") return "No";
  return "Pending";
}

function getVisibleProgressLabel(tool) {
  if (!tool) return "0% mentor reviewed";
  return `${tool.reviewedPercent || 0}% mentor reviewed - ${tool.status || "Not reviewed"}`;
}

function LearningProgressCard({ item, onSave }) {
  const [raw, setRaw] = useState((item.enrollment.modulesCompleted || []).join(","));

  return (
    <article className="tile">
      <h3>{item.course.title}</h3>
      <p>Progress: {item.enrollment.progress || 0}%</p>
      <p>Completed module indexes (comma separated):</p>
      <div className="inline">
        <input value={raw} onChange={(e) => setRaw(e.target.value)} placeholder="e.g. 0,1,2" />
        <button className="btn" onClick={() => onSave(item.course.id, raw)}>Save</button>
      </div>
    </article>
  );
}

function ProjectEditor({ project, onSave, onUpload }) {
  const [forms, setForms] = useState({ ...DEFAULT_FORMS, ...(project.forms || {}) });
  const linkedTool = getProjectTool(project);
  const mentorReview = linkedTool ? project.mentorToolReviews?.[linkedTool.key] || null : null;

  return (
    <article className="tile">
      <h3>{project.title}</h3>
      <p>Type: {project.type} | Stage: {project.stage} | Status: <strong>{project.status}</strong></p>
      {getCorrectionStatus(mentorReview) ? (
        <div className="mentor-correction-summary">
          <span className={`correction-badge correction-badge-${getCorrectionStatus(mentorReview)}`}>
            {getCorrectionLabel(mentorReview)}
          </span>
          <p>
            Mentor corrected this work on {dayjs(mentorReview.reviewedAt).format("DD MMM YYYY")}.
          </p>
        </div>
      ) : null}
      <div className="form-stack">
        <textarea rows="2" placeholder="Value proposition" value={forms.valueProposition || ""} onChange={(e) => setForms({ ...forms, valueProposition: e.target.value })} />
        <textarea rows="2" placeholder="Customer segments" value={forms.customerSegments || ""} onChange={(e) => setForms({ ...forms, customerSegments: e.target.value })} />
        <textarea rows="2" placeholder="Channels" value={forms.channels || ""} onChange={(e) => setForms({ ...forms, channels: e.target.value })} />
        <textarea rows="2" placeholder="Revenue streams" value={forms.revenueStreams || ""} onChange={(e) => setForms({ ...forms, revenueStreams: e.target.value })} />
        <textarea rows="2" placeholder="Environmental sustainability impact" value={forms.environmentalImpact || ""} onChange={(e) => setForms({ ...forms, environmentalImpact: e.target.value })} />
        <textarea rows="2" placeholder="Social sustainability impact" value={forms.socialImpact || ""} onChange={(e) => setForms({ ...forms, socialImpact: e.target.value })} />
        <textarea rows="2" placeholder="Economic plan" value={forms.financialPlan || ""} onChange={(e) => setForms({ ...forms, financialPlan: e.target.value })} />
      </div>
      <div className="inline">
        <button className="btn" onClick={() => onSave(project.id, forms, false)}>Save draft</button>
        <button className="btn primary" onClick={() => onSave(project.id, forms, true)}>Submit</button>
      </div>
      <div className="inline">
        <input type="file" onChange={(e) => e.target.files[0] && onUpload(project.id, e.target.files[0])} />
      </div>
      {(project.feedback || []).length ? <p>Latest feedback: {(project.feedback || []).slice(-1)[0].detailedFeedback}</p> : null}
      {(project.recommendations || []).length ? <p>Latest recommendation: {(project.recommendations || []).slice(-1)[0].text}</p> : null}
      {mentorReview?.recommendation || mentorReview?.comment ? (
        <div className="mentor-comment-callout">
          <strong>{getCorrectionStatus(mentorReview) === "no" ? "Why no" : "Mentor comment"}</strong>
          <p>{mentorReview.recommendation || mentorReview.comment}</p>
        </div>
      ) : null}
      {(project.privateLessons || []).length ? (
        <div className="mentor-private-lessons">
          <strong>Private lessons from mentor</strong>
          {(project.privateLessons || []).map((lesson) => (
            <div key={lesson.id} className="module mentor-private-lesson">
              <p>{lesson.title}</p>
              {lesson.description ? <p>{lesson.description}</p> : null}
              {isVideoLesson(lesson) ? (
                <video className="mentor-private-video" controls src={resolveMediaUrl(lesson.path)}></video>
              ) : null}
              <a href={resolveMediaUrl(lesson.path)} target="_blank" rel="noreferrer">
                Open lesson file
              </a>
            </div>
          ))}
        </div>
      ) : null}
    </article>
  );
}
